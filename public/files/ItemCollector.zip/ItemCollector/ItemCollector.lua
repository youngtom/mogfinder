local mcc = {}
local bankOpen, collectionsHooked = false, false
local unscannedBags, bagScanTimes = {}, {}
local lastInventoryScan, lastVoidScan = 0, 0
local guid = nil
local classColor = "|cFFFFFFFF"

-- Libs
local LibRealmInfo = LibStub('LibRealmInfo')

-- Defaults
local defaultMCCSaved = {
    ver = modVersion,
    chars = {},
    heirlooms = {}
}

-- Constants
local modVersion = 2
local SLOTS_PER_VOID_STORAGE_TAB = 80
local inventorySlots = { 1, 3, 4, 5, 6, 7, 8, 9, 10, 15, 16, 17, 18, 19 }
local bankBagIDs = { -1, 5, 6, 7, 8, 9, 10, 11 }
local bagIDs = { 0, 1, 2, 3, 4 }
local colors = {
	["WARRIOR"]=1,["PALADIN"]="|cFFF58CBA",["HUNTER"]="|cFFABD473",["ROGUE"]="|cFFFFF569",["PRIEST"]="|cFFFFFFFF",
	["DEATHKNIGHT"]="|cFFC41F3B",["SHAMAN"]="|cFF0070DE",["MAGE"]="|cFF69CCF0",["WARLOCK"]="|cFF9482C9",["DRUID"]="|cFFFF7D0A",
	["MONK"]="|cFFC79C6E"
}

-- Frame for events
local frame, events = CreateFrame("FRAME"), {}

function events:ADDON_LOADED(name)
    if name == "ItemCollector" then
        MCCSaved = MCCSaved or defaultMCCSaved

        -- Overwrite with default if out of date
        if not MCCSaved.ver or MCCSaved.ver < defaultMCCSaved.ver then
            MCCSaved = defaultMCCSaved
        end

        MCCSaved.heirlooms = MCCSaved.heirlooms or {}

        mcc:HookCollections()
    elseif name == "Blizzard_Collections" then
        mcc:HookCollections()
    end
end

function events:PLAYER_LOGIN()
    for k, v in pairs (bagIDs) do
        unscannedBags[v] = true
    end
    mcc:Init()
end

function events:BAG_UPDATE(bagID)
    unscannedBags[bagID] = true
    mcc:Scan()
end

function events:BANKFRAME_OPENED()
    bankOpen = true
    for k, v in pairs (bankBagIDs) do
        unscannedBags[v] = true
    end
    mcc:Scan()
end

function events:BANKFRAME_CLOSED()
    bankOpen = false
end

function events:VOID_STORAGE_OPEN()
    if IsVoidStorageReady() then
        mcc:ScanVoidStorage()
    end
end

function events:VOID_STORAGE_UPDATE()
    mcc:ScanVoidStorage()
end

function events:VOID_STORAGE_CONTENTS_UPDATE()
    mcc:ScanVoidStorage()
end

function events:VOID_TRANSFER_DONE()
    mcc:ScanVoidStorage()
end

function events:UNIT_INVENTORY_CHANGED(unit)
    if unit ~= 'player' then return end

    if (lastInventoryScan < time()) then
      mcc:ScanInventory()
    end
end
-------------------------------------------------------------------------------
frame:SetScript("OnEvent", function(self, event, ...)
    events[event](self, ...)
end)

-- Register every event in the events table
for k, v in pairs(events) do
    frame:RegisterEvent(k)
end
-------------------------------------------------------------------------------
function mcc:Scan()
    local curTime = time()
    -- Scan unscanned bags
    for bagID, unscanned in pairs(unscannedBags) do
        local bagScanTime = bagScanTimes[bagID] or 0

        if (bagScanTime < curTime) then
          bagScanTimes[bagID] = curTime
          unscannedBags[bagID] = nil
          mcc:ScanBag(bagID)
        end
    end
end
-------------------------------------------------------------------------------

function mcc:Init()
    guid = UnitGUID("player")

    -- Set up character data table
    MCCSaved.chars[guid] = MCCSaved.chars[guid] or {}

    MCCSaved.chars[guid].items = MCCSaved.chars[guid].items or {}
    MCCSaved.chars[guid].scanTime = time()
    MCCSaved.chars[guid].charInfo = {}

    local _, realm, _, _, _, _, region = LibRealmInfo:GetRealmInfoByUnit("player")
    local regionName = region or GetCurrentRegion()
    local class, classFileName = UnitClass("player")
    local race, raceFileName = UnitRace("player")

    MCCSaved.chars[guid].charInfo.name = UnitName("player")
    MCCSaved.chars[guid].charInfo.faction = UnitFactionGroup("player")
    MCCSaved.chars[guid].charInfo.class = classFileName
    MCCSaved.chars[guid].charInfo.race = raceFileName
    MCCSaved.chars[guid].charInfo.level = UnitLevel("player")

    classColor = colors[classFileName]

    if (realm and regionName) then
        MCCSaved.chars[guid].charInfo.realm = realm
        MCCSaved.chars[guid].charInfo.region = regionName
    end

    DEFAULT_CHAT_FRAME:AddMessage("|cFF0070DEMogCollector.com |cFF69CCF0ItemCollector |cFFFFFFFFv" .. modVersion .. " by |cFFFF7D0Atritus|cFFFFFFFF@Mal'Ganis loaded (/mcc)")

    mcc:ScanInventory()
    mcc:Scan()
end

local cTip = CreateFrame("GameTooltip","MCCTooltip",nil,"GameTooltipTemplate")
function mcc:IsSoulbound(bag, slot)
    cTip:SetOwner(UIParent, "ANCHOR_NONE")

    if (bag == -1) then
      cTip:SetInventoryItem("player", BankButtonIDToInvSlotID(slot, nil))
    elseif (bag == "void") then
      cTip:SetVoidItem(1, slot)
    else
      cTip:SetBagItem(bag, slot)
    end

    cTip:Show()

    for i = 1,cTip:NumLines() do
        local tpText = _G["MCCTooltipTextLeft"..i]:GetText()
        if(tpText==ITEM_SOULBOUND or tpText==ITEM_BIND_ON_PICKUP) then
            return 1
        elseif(tpText==ITEM_ACCOUNTBOUND or tpText==ITEM_BIND_TO_BNETACCOUNT or tpText==ITEM_BIND_TO_ACCOUNT) then
            return 2
        end
    end
    cTip:Hide()
    return 0
end

function mcc:IsTransmoggable(itemID)
  local _, _, canBeSource, noSourceReason = GetItemTransmogrifyInfo(itemID)
  local _, link = GetItemInfo(itemID)
  if (canBeSource) then
    return 1
  else
    return 0
  end
end

function mcc:ScanBag(bagID)
    if MCCSaved.chars[guid] == nil then return end

    if (bagID == -3 or bagID == -1 or (bagID >= 5 and bagID <= 11)) and not bankOpen then
        return
    end

    MCCSaved.chars[guid].items["bag "..bagID] = {}
    local bag = MCCSaved.chars[guid].items["bag "..bagID]

    local numSlots = GetContainerNumSlots(bagID)
    if numSlots > 0 then
        for i = 1, numSlots do
            local texture, count, locked, quality, readable, lootable, link, isFiltered = GetContainerItemInfo(bagID, i)
            local itemID = GetContainerItemID(bagID, i)
            local bound = mcc:IsSoulbound(bagID, i)
            if count ~= nil and link ~= nil and IsEquippableItem(link) then
                bag["s"..i] = bound .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
            end
        end
    end
end

-- Scan void storage
function mcc:ScanVoidStorage()
    if (lastVoidScan >= time() or MCCSaved.chars[guid] == nil) then return end

    lastVoidScan = time()

    for i = 1, 2 do
        MCCSaved.chars[guid].items["void "..i] = {}
        local void = MCCSaved.chars[guid].items["void "..i]

        for j = 1, SLOTS_PER_VOID_STORAGE_TAB do
            local itemID, texture, locked, recentDeposit, isFiltered = GetVoidItemInfo(i, j)
            local voidSlot = j + ((i - 1) * SLOTS_PER_VOID_STORAGE_TAB)
            local link = GetVoidItemHyperlinkString(voidSlot)
            local bound = mcc:IsSoulbound("void", voidSlot)
            if itemID ~= nil and IsEquippableItem(itemID) then
                void["s"..j] = bound .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
            end
        end
    end
end

-- Scan Inventory
function mcc:ScanInventory()
  if MCCSaved.chars[guid] == nil then return end

  lastInventoryScan = time()
  MCCSaved.chars[guid].equipped = {}

  for i, invID in ipairs(inventorySlots) do
    local itemID = GetInventoryItemID("player", invID)
    local link = GetInventoryItemLink("player", invID)
    if itemID ~= nil and link ~= nil then
      MCCSaved.chars[guid].equipped["s"..i] = 1 .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
    end
  end
end

function mcc:HookCollections()
    if not IsAddOnLoaded("Blizzard_Collections") then
        LoadAddOn("Blizzard_Collections")
    else
        if not collectionsHooked then
            -- Hook heirlooms
            local hlframe = _G["HeirloomsJournal"]
            if hlframe then
                hlframe:HookScript("OnShow", function(self)
                    mcc:ScanHeirlooms()
                end)
            end

            collectionsHooked = true
        end
    end
end

-- Scan heirlooms
function mcc:ScanHeirlooms()
    if MCCSaved.chars[guid] == nil then return end

    MCCSaved.heirlooms = {}

    for i = 1, C_Heirloom.GetNumHeirlooms() do
        local itemID = C_Heirloom.GetHeirloomItemIDFromIndex(i)
        if C_Heirloom.PlayerHasHeirloom(itemID) then
            MCCSaved.heirlooms[itemID] = mcc:IsTransmoggable(itemID)
        end
    end
end

function mcc:ScanInfo()
    local bagCount, bankCount, voidCount, heirloomCount, equippedCount = 0, 0, 0, 0, 0

    --get bag count
    for _, v in pairs (bagIDs) do
      local k = "bag " .. v
      if (type(MCCSaved.chars[guid].items[k]) ~= nil) then
        for _, link in pairs (MCCSaved.chars[guid].items[k]) do
          bagCount = bagCount + 1
        end
      end
    end

    --get bank count
    for _, v in pairs (bankBagIDs) do
      local k = "bag " .. v
      if (type(MCCSaved.chars[guid].items[k]) ~= nil) then
        for _, link in pairs (MCCSaved.chars[guid].items[k]) do
          bankCount = bankCount + 1
        end
      end
    end

    --get void count
    for i = 1, 2 do
      local k = "void " .. i
      if (type(MCCSaved.chars[guid].items[k]) ~= nil) then
        for _, link in pairs (MCCSaved.chars[guid].items[k]) do
          voidCount = voidCount + 1
        end
      end
    end

    --get heirloom count
    for _ in pairs(MCCSaved.heirlooms) do heirloomCount = heirloomCount + 1 end

    --get equipped count
    for _ in pairs(MCCSaved.chars[guid].equipped) do equippedCount = equippedCount + 1 end

    local total = bagCount + bankCount + heirloomCount + voidCount + equippedCount

    if (bagCount == 0) then bagCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (bankCount == 0) then bankCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (heirloomCount == 0) then heirloomCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (voidCount == 0) then voidCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (equippedCount == 0) then equippedCount = "|cFF69CCF0EMPTY/UNSCANNED" end

    DEFAULT_CHAT_FRAME:AddMessage("Item counts for " .. classColor .. MCCSaved.chars[guid].charInfo.name)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFFFFFFF  Equipped: |cFFFFFFFF"..equippedCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFF1eff00  Bags: |cFFFFFFFF"..bagCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFF0070dd  Bank: |cFFFFFFFF"..bankCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFa335ee  Void Storage: |cFFFFFFFF"..voidCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFe5ccb0  Heirlooms: |cFFFFFFFF"..heirloomCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFffb000TOTAL: |cFFFFFFFF"..total)
end

-- slash command
SLASH_ITEMCOLLECTOR1 = '/mcc';
local function handler(msg, editBox)
    mcc:ScanInfo()
end
SlashCmdList["ITEMCOLLECTOR"] = handler;
