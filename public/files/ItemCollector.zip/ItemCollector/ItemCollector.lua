local bankOpen, collectionsHooked, charInfoLoaded, addonLoaded, voidScanQueued, voidStorageOpen = false, false, false, false, false, false
local lastInventoryScan = 0
local guid = nil
local classColor = "|cFFFFFFFF"

local addonName, mcc = ...
ItemCollector = LibStub("AceAddon-3.0"):NewAddon(mcc, addonName, "AceEvent-3.0", "AceTimer-3.0")

-- Libs
local realmInfo = LibStub:GetLibrary('LibRealmInfo')

-- Constants
local modVersion = "2.0.4"
local SLOTS_PER_VOID_STORAGE_TAB = 80
local inventorySlots = { 1, 3, 4, 5, 6, 7, 8, 9, 10, 15, 16, 17, 18, 19 }
local bankBagIDs = { -1, 5, 6, 7, 8, 9, 10, 11 }
local bagIDs = { 0, 1, 2, 3, 4 }
local colors = {
	["WARRIOR"]="|cFFc79c6e",["PALADIN"]="|cFFF58CBA",["HUNTER"]="|cFFABD473",["ROGUE"]="|cFFFFF569",["PRIEST"]="|cFFFFFFFF",
	["DEATHKNIGHT"]="|cFFC41F3B",["SHAMAN"]="|cFF0070DE",["MAGE"]="|cFF69CCF0",["WARLOCK"]="|cFF9482C9",["DRUID"]="|cFFFF7D0A",
	["MONK"]="|cFF00ff96"
}

-- Defaults
local defaultMCCSaved = {
    ver = modVersion,
    chars = {},
    heirlooms = {}
}

-- Event handlers
local function OnBagUpdate(event, bagID)
	mcc:ScanBag(bagID)
end

local function OnBankOpened()
	bankOpen = true
	for k, bagID in pairs (bankBagIDs) do
			mcc:ScanBag(bagID)
	end
end

local function OnBankClosed()
	bankOpen = false
end

local function OnUnitInventoryChanged(unit)
	if unit ~= 'player' then return end

	if (lastInventoryScan < time()) then
		mcc:ScanInventory()
	end
end

local function QueueVoidStorageScan()
	if (IsVoidStorageReady() and not voidScanQueued) then
		voidScanQueued = true
		mcc:ScheduleTimer("ScanVoidStorage", 0.1)
	end
end

local function OnVoidStorageClosed()
	voidStorageOpen = false
	mcc:UnregisterEvent("VOID_STORAGE_CLOSE")
	mcc:UnregisterEvent("VOID_STORAGE_UPDATE")
	mcc:UnregisterEvent("VOID_STORAGE_CONTENTS_UPDATE")
	mcc:UnregisterEvent("VOID_TRANSFER_DONE")
end

local function OnVoidStorageTransferDone()
	QueueVoidStorageScan()
end

local function OnVoidStorageOpened()
	voidStorageOpen = true
	QueueVoidStorageScan()
	mcc:RegisterEvent("VOID_STORAGE_CLOSE", OnVoidStorageClosed)
	mcc:RegisterEvent("VOID_STORAGE_UPDATE", QueueVoidStorageScan)
	mcc:RegisterEvent("VOID_STORAGE_CONTENTS_UPDATE", QueueVoidStorageScan)
	mcc:RegisterEvent("VOID_TRANSFER_DONE", OnVoidStorageTransferDone)
end

-- addon setup
function mcc:OnInitialize()
	MCCSaved = MCCSaved or defaultMCCSaved

	if (not MCCSaved.ver or type(MCCSaved.ver) ~= "string") then
		MCCSaved = defaultMCCSaved
	else
		local majV, minV, revV = modVersion:match("(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)")
		local savedMajV, savedMinV, savedRevV = MCCSaved.ver:match("(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)")

		if savedMajV < majV then
			MCCSaved = defaultMCCSaved
		end
	end

	MCCSaved.ver = modVersion
	MCCSaved.heirlooms = MCCSaved.heirlooms or {}

	mcc:HookCollections()
end

function mcc:OnEnable()
	for k, bagID in pairs (bagIDs) do
			mcc:ScanBag(bagID)
	end

	mcc:RegisterEvent("BAG_UPDATE", OnBagUpdate)
	mcc:RegisterEvent("BANKFRAME_OPENED", OnBankOpened)
	mcc:RegisterEvent("BANKFRAME_CLOSED", OnBankClosed)
	mcc:RegisterEvent("UNIT_INVENTORY_CHANGED", OnUnitInventoryChanged)
	mcc:RegisterEvent("VOID_STORAGE_OPEN", OnVoidStorageOpened)

	mcc:Init()
	addonLoaded = true
	self:ScheduleTimer("LoadCharInfo", 3)
end

--- Handling Blizzard_Collections loading
-- Frame for events
local frame, events = CreateFrame("FRAME"), {}

function events:ADDON_LOADED(name)
    if name == "Blizzard_Collections" then
        mcc:HookCollections()
    end
end

frame:SetScript("OnEvent", function(self, event, ...)
    events[event](self, ...)
end)

for k, v in pairs(events) do
    frame:RegisterEvent(k)
end

-------------------------------------------------------------------------------

function mcc:Init()
    guid = UnitGUID("player")

    -- Set up character data table
    MCCSaved.chars[guid] = MCCSaved.chars[guid] or {}
    MCCSaved.chars[guid].items = MCCSaved.chars[guid].items or {}
    MCCSaved.chars[guid].scanTime = time()

    mcc:ScanInventory()
end

function mcc:LoadCharInfo()
		if (not addonLoaded or charInfoLoaded) then return end
		guid = UnitGUID("player")

		MCCSaved.chars[guid].charInfo = MCCSaved.chars[guid].charInfo or {}

		local _, realm, _, _, _, _, region = realmInfo:GetRealmInfoByUnit("player")

		if (realm == nil) then
			realm = GetRealmName()
		end

		local regionName = region or GetCurrentRegion()
		local class, classFileName = UnitClass("player")
		local race, raceFileName = UnitRace("player")

		MCCSaved.chars[guid].charInfo.name = UnitName("player")
		MCCSaved.chars[guid].charInfo.faction = UnitFactionGroup("player")
		MCCSaved.chars[guid].charInfo.class = classFileName
		MCCSaved.chars[guid].charInfo.race = raceFileName
		MCCSaved.chars[guid].charInfo.level = UnitLevel("player")

		classColor = colors[classFileName]

		if (realm) then
				MCCSaved.chars[guid].charInfo.realm = realm
		end

		if (regionName) then
				MCCSaved.chars[guid].charInfo.region = regionName
		end

		charInfoLoaded = true

		DEFAULT_CHAT_FRAME:AddMessage("|cFF0070DEMogCollector.com |cFF69CCF0ItemCollector |cFFFFFFFFv" .. modVersion .. " by |cFFFF7D0Atritus|cFFFFFFFF@Mal'Ganis loaded (/mcc)")
end

local cTip = CreateFrame("GameTooltip","MCCTooltip",nil,"GameTooltipTemplate")
function mcc:IsSoulbound(bag, slot)
    cTip:SetOwner(UIParent, "ANCHOR_NONE")

    if (bag == -1) then
      cTip:SetInventoryItem("player", BankButtonIDToInvSlotID(slot, nil))
    elseif (bag == "void") then
      cTip:SetVoidItem(1, slot)
    else
      cTip:SetBagItem(bag, slot)
    end

    cTip:Show()

    for i = 1,cTip:NumLines() do
        local tpText = _G["MCCTooltipTextLeft"..i]:GetText()
        if(tpText==ITEM_SOULBOUND or tpText==ITEM_BIND_ON_PICKUP) then
            return 1
        elseif(tpText==ITEM_ACCOUNTBOUND or tpText==ITEM_BIND_TO_BNETACCOUNT or tpText==ITEM_BIND_TO_ACCOUNT) then
            return 2
        end
    end
    cTip:Hide()
    return 0
end

function mcc:IsTransmoggable(itemID)
  local _, _, canBeSource, noSourceReason = GetItemTransmogrifyInfo(itemID)
  local _, link = GetItemInfo(itemID)
  if (canBeSource) then
    return 1
  else
    return 0
  end
end

function mcc:ScanBag(bagID)
    if MCCSaved.chars[guid] == nil then return end

    if (bagID == -3 or bagID == -1 or (bagID >= 5 and bagID <= 11)) and not bankOpen then
        return
    end

    MCCSaved.chars[guid].items["bag "..bagID] = {}
    local bag = MCCSaved.chars[guid].items["bag "..bagID]

    local numSlots = GetContainerNumSlots(bagID)
    if numSlots > 0 then
        for i = 1, numSlots do
            local texture, count, locked, quality, readable, lootable, link, isFiltered = GetContainerItemInfo(bagID, i)
            local itemID = GetContainerItemID(bagID, i)
            local bound = mcc:IsSoulbound(bagID, i)
            if count ~= nil and link ~= nil and IsEquippableItem(link) then
                bag["s"..i] = bound .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
            end
        end
    end
end

-- Scan void storage
function mcc:ScanVoidStorage()
    if (MCCSaved.chars[guid] == nil or not voidScanQueued) then return end

		if (not voidStorageOpen) then
			voidScanQueued = false
			return
		end

    for i = 1, 2 do
        MCCSaved.chars[guid].items["void "..i] = {}
        local void = MCCSaved.chars[guid].items["void "..i]

        for j = 1, SLOTS_PER_VOID_STORAGE_TAB do
            local itemID, texture, locked, recentDeposit, isFiltered = GetVoidItemInfo(i, j)
            local voidSlot = j + ((i - 1) * SLOTS_PER_VOID_STORAGE_TAB)
            local link = GetVoidItemHyperlinkString(voidSlot)
            local bound = mcc:IsSoulbound("void", voidSlot)
            if itemID ~= nil and IsEquippableItem(itemID) then
                void["s"..j] = bound .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
            end
        end
    end
		voidScanQueued = false
end

-- Scan Inventory
function mcc:ScanInventory()
  if MCCSaved.chars[guid] == nil then return end

  lastInventoryScan = time()
  MCCSaved.chars[guid].equipped = {}

  for i, invID in ipairs(inventorySlots) do
    local itemID = GetInventoryItemID("player", invID)
    local link = GetInventoryItemLink("player", invID)
    if itemID ~= nil and link ~= nil then
      MCCSaved.chars[guid].equipped["s"..i] = 1 .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
    end
  end
end

function mcc:HookCollections()
    if not IsAddOnLoaded("Blizzard_Collections") then
        LoadAddOn("Blizzard_Collections")
    else
        if not collectionsHooked then
            -- Hook heirlooms
            local hlframe = _G["HeirloomsJournal"]
            if hlframe then
                hlframe:HookScript("OnShow", function(self)
                    mcc:ScanHeirlooms()
                end)
            end

            collectionsHooked = true
        end
    end
end

-- Scan heirlooms
function mcc:ScanHeirlooms()
    if MCCSaved.chars[guid] == nil then return end
    MCCSaved.heirlooms = {}

    for i = 1, C_Heirloom.GetNumHeirlooms() do
        local itemID = C_Heirloom.GetHeirloomItemIDFromIndex(i)
        if C_Heirloom.PlayerHasHeirloom(itemID) then
            MCCSaved.heirlooms[itemID] = mcc:IsTransmoggable(itemID)
        end
    end
end

function mcc:ScanInfo()
    local bagCount, bankCount, voidCount, heirloomCount, equippedCount = 0, 0, 0, 0, 0

    if (type(MCCSaved.chars[guid].items) ~= nil) then
      --get bag count
      for _, v in pairs (bagIDs) do
        local k = "bag " .. v
        if (type(MCCSaved.chars[guid].items[k]) ~= nil and MCCSaved.chars[guid].items[k] ~= nil) then
          for _, link in pairs (MCCSaved.chars[guid].items[k]) do
            bagCount = bagCount + 1
          end
        end
      end

      --get bank count
      for _, v in pairs (bankBagIDs) do
        local k = "bag " .. v
        if (type(MCCSaved.chars[guid].items[k]) ~= nil and MCCSaved.chars[guid].items[k] ~= nil) then
          for _, link in pairs (MCCSaved.chars[guid].items[k]) do
            bankCount = bankCount + 1
          end
        end
      end

      --get void count
      for i = 1, 2 do
        local k = "void " .. i
        if (type(MCCSaved.chars[guid].items[k]) ~= nil and MCCSaved.chars[guid].items[k] ~= nil) then
          for _, link in pairs (MCCSaved.chars[guid].items[k]) do
            voidCount = voidCount + 1
          end
        end
      end
    end

    --get heirloom count
    for _ in pairs(MCCSaved.heirlooms) do heirloomCount = heirloomCount + 1 end

    --get equipped count
    for _ in pairs(MCCSaved.chars[guid].equipped) do equippedCount = equippedCount + 1 end

    local total = bagCount + bankCount + heirloomCount + voidCount + equippedCount

    if (bagCount == 0) then bagCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (bankCount == 0) then bankCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (heirloomCount == 0) then heirloomCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (voidCount == 0) then voidCount = "|cFF69CCF0EMPTY/UNSCANNED" end
    if (equippedCount == 0) then equippedCount = "|cFF69CCF0EMPTY/UNSCANNED" end

    DEFAULT_CHAT_FRAME:AddMessage("Item counts for " .. classColor .. MCCSaved.chars[guid].charInfo.name)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFFFFFFF  Equipped: |cFFFFFFFF"..equippedCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFF1eff00  Bags: |cFFFFFFFF"..bagCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFF0070dd  Bank: |cFFFFFFFF"..bankCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFa335ee  Void Storage: |cFFFFFFFF"..voidCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFe5ccb0  Heirlooms: |cFFFFFFFF"..heirloomCount)
    DEFAULT_CHAT_FRAME:AddMessage("|cFFffb000TOTAL: |cFFFFFFFF"..total)
end

-- slash command
SLASH_ITEMCOLLECTOR1 = '/mcc';
local function handler(msg, editBox)
    mcc:ScanInfo()
end
SlashCmdList["ITEMCOLLECTOR"] = handler;
