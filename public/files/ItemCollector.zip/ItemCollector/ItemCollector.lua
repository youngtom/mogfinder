local mcc = {}
local charData
local bankOpen, collectionsHooked = false, false
local unscannedBags, unscannedVoid, unscannedInventory = {}, false, false

-- Libs
local LibRealmInfo = LibStub('LibRealmInfo')

-- Defaults
local defaultMCCSaved = {
    ver = 2,
    chars = {},
    heirlooms = {}
}

-- Constants
local SLOTS_PER_VOID_STORAGE_TAB = 80
local inventorySlots = { 1, 3, 4, 5, 6, 7, 8, 9, 10, 15, 16, 17, 18, 19 }

-- Frame for events
local frame, events = CreateFrame("FRAME"), {}

function events:ADDON_LOADED(name)
    if name == "ItemCollector" then
        MCCSaved = MCCSaved or defaultMCCSaved

        -- Overwrite with default if out of date
        if not MCCSaved.ver or MCCSaved.ver < defaultMCCSaved.ver then
            MCCSaved = defaultMCCSaved
        end

        MCCSaved.heirlooms = MCCSaved.heirlooms or {}

        mcc:HookCollections()
    elseif name == "Blizzard_Collections" then
        mcc:HookCollections()
    end
end

function events:PLAYER_LOGIN()
    mcc:Login()
end

function events:PLAYER_LOGOUT()
    mcc:Logout()
end

function events:BAG_UPDATE(bagID)
    unscannedBags[bagID] = true
end

function events:BANKFRAME_OPENED()
    -- Force a bag scan of the bank now that it's open
    bankOpen = true
    unscannedBags[-1] = true
    for i = 5, 11 do
        unscannedBags[i] = true
    end
end

function events:BANKFRAME_CLOSED()
    bankOpen = false
end

function events:VOID_STORAGE_OPEN()
    if IsVoidStorageReady() then
        unscannedVoid = true
    end
end

function events:VOID_STORAGE_UPDATE()
    unscannedVoid = true
end

function events:VOID_STORAGE_CONTENTS_UPDATE()
    unscannedVoid = true
end

function events:VOID_TRANSFER_DONE()
    unscannedVoid = true
end

function events:UNIT_INVENTORY_CHANGED(unit)
    if unit ~= 'player' then return end
    unscannedInventory = true
end

-------------------------------------------------------------------------------
-- Call functions in the events table for events
frame:SetScript("OnEvent", function(self, event, ...)
    events[event](self, ...)
end)

-- Register every event in the events table
for k, v in pairs(events) do
    frame:RegisterEvent(k)
end

-------------------------------------------------------------------------------
-- Timer to do spammy things
function mcc:Timer()
    -- Scan unscanned bags
    for bagID, unscanned in pairs(unscannedBags) do
        unscannedBags[bagID] = nil
        mcc:ScanBag(bagID)
    end
    -- Scan unscanned void storage
    if unscannedVoid then
        unscannedVoid = false
        mcc:ScanVoidStorage()
    end
    -- Scan inventory
    if unscannedInventory then
      unscannedInventory = false
      mcc:ScanInventory()
    end
end

local _ = C_Timer.NewTicker(1, function() mcc:Timer() end, nil)

-------------------------------------------------------------------------------

function mcc:Init()
    local guid = UnitGUID("player")

    -- Set up character data table
    charData = MCCSaved.chars[guid] or {}
    MCCSaved.chars[guid] = charData

    charData.items = charData.items or {}
    charData.scanTime = time()
    charData.charInfo = {}

    local _, realm, _, _, _, _, region = LibRealmInfo:GetRealmInfoByUnit("player")
    local regionName = region or GetCurrentRegion()
    local class, classFileName = UnitClass("player")
    local race, raceFileName = UnitRace("player")

    charData.charInfo.name = UnitName("player")
    charData.charInfo.realm = realm
    charData.charInfo.region = regionName
    charData.charInfo.faction = UnitFactionGroup("player")
    charData.charInfo.class = classFileName
    charData.charInfo.race = raceFileName
    charData.charInfo.level = UnitLevel("player")

    mcc:ScanInventory()
end

function mcc:Login()
    mcc:Init()
end

function mcc:Logout()
    loggingOut = true
end

local cTip = CreateFrame("GameTooltip","MCCTooltip",nil,"GameTooltipTemplate")
function mcc:IsSoulbound(bag, slot)
    cTip:SetOwner(UIParent, "ANCHOR_NONE")

    if (bag == -1) then
      cTip:SetInventoryItem("player", BankButtonIDToInvSlotID(slot, nil))
    elseif (bag == "void") then
      cTip:SetVoidItem(1, slot)
    else
      cTip:SetBagItem(bag, slot)
    end

    cTip:Show()

    for i = 1,cTip:NumLines() do
        local tpText = _G["MCCTooltipTextLeft"..i]:GetText()
        if(tpText==ITEM_SOULBOUND or tpText==ITEM_BIND_ON_PICKUP) then
            return 1
        elseif(tpText==ITEM_ACCOUNTBOUND or tpText==ITEM_BIND_TO_BNETACCOUNT or tpText==ITEM_BIND_TO_ACCOUNT) then
            return 2
        end
    end
    cTip:Hide()
    return 0
end

function mcc:IsTransmoggable(itemID)
  local _, _, canBeSource, noSourceReason = GetItemTransmogrifyInfo(itemID)
  local _, link = GetItemInfo(itemID)
  if (canBeSource) then
    return 1
  else
    return 0
  end
end

function mcc:ScanBag(bagID)
    if charData == nil then return end

    -- Short circuit if bank isn't open
    if (bagID == -3 or bagID == -1 or (bagID >= 5 and bagID <= 11)) and not bankOpen then
        return
    end

    charData.items["bag "..bagID] = {}
    local bag = charData.items["bag "..bagID]

    local numSlots = GetContainerNumSlots(bagID)
    if numSlots > 0 then
        for i = 1, numSlots do
            local texture, count, locked, quality, readable, lootable, link, isFiltered = GetContainerItemInfo(bagID, i)
            local itemID = GetContainerItemID(bagID, i)
            local bound = mcc:IsSoulbound(bagID, i)
            if count ~= nil and link ~= nil and IsEquippableItem(link) then
                bag["s"..i] = bound .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
            end
        end
    end
end

-- Scan void storage
function mcc:ScanVoidStorage()
    if charData == nil then return end

    -- NOTE: constants appear to not be global, woo
    for i = 1, 2 do
        charData.items["void "..i] = {}
        local void = charData.items["void "..i]

        for j = 1, SLOTS_PER_VOID_STORAGE_TAB do
            local itemID, texture, locked, recentDeposit, isFiltered = GetVoidItemInfo(i, j)
            local voidSlot = j + ((i - 1) * SLOTS_PER_VOID_STORAGE_TAB)
            local link = GetVoidItemHyperlinkString(voidSlot)
            local bound = mcc:IsSoulbound("void", voidSlot)
            if itemID ~= nil and IsEquippableItem(itemID) then
                void["s"..j] = bound .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
            end
        end
    end
end

-- Scan Inventory
function mcc:ScanInventory()
  if charData == nil then return end

  charData.equipped = {}

  for i, invID in ipairs(inventorySlots) do
    local itemID = GetInventoryItemID("player", invID)
    local link = GetInventoryItemLink("player", invID)
    if itemID ~= nil and link ~= nil then
      charData.equipped["s"..i] = 1 .. '--' .. mcc:IsTransmoggable(itemID) .. '--' .. link
    end
  end
end

-- Hook various Blizzard_Collections things for scanning
function mcc:HookCollections()
    if not IsAddOnLoaded("Blizzard_Collections") then
        LoadAddOn("Blizzard_Collections")
    else
        if not collectionsHooked then
            -- Hook heirlooms
            local hlframe = _G["HeirloomsJournal"]
            if hlframe then
                hlframe:HookScript("OnShow", function(self)
                    mcc:ScanHeirlooms()
                end)
            else
                print("ItemCollector: unable to hook 'HeirloomsJournal' frame!")
            end

            collectionsHooked = true
        end
    end
end

-- Scan heirlooms
function mcc:ScanHeirlooms()
    if charData == nil then return end

    MCCSaved.heirlooms = {}

    for i = 1, C_Heirloom.GetNumHeirlooms() do
        local itemID = C_Heirloom.GetHeirloomItemIDFromIndex(i)
        if C_Heirloom.PlayerHasHeirloom(itemID) then
            MCCSaved.heirlooms[itemID] = mcc:IsTransmoggable(itemID)
        end
    end
end
