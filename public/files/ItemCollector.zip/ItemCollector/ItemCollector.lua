local classColor = "|cFFFFFFFF"
local scanningData, charInfoLoaded, addonLoaded = false, false, false
local guid = nil
local newAppearances = 0
local wardrobeScanHelper = nil

local addonName, mcc = ...
ItemCollector = LibStub("AceAddon-3.0"):NewAddon(mcc, addonName, "AceEvent-3.0", "AceTimer-3.0")

-- Libs
local realmInfo = LibStub:GetLibrary('LibRealmInfo')

-- Constants
local modVersion = "3.0.0"
local colors = {
	["WARRIOR"]="|cFFc79c6e",["PALADIN"]="|cFFF58CBA",["HUNTER"]="|cFFABD473",["ROGUE"]="|cFFFFF569",["PRIEST"]="|cFFFFFFFF",
	["DEATHKNIGHT"]="|cFFC41F3B",["SHAMAN"]="|cFF0070DE",["MAGE"]="|cFF69CCF0",["WARLOCK"]="|cFF9482C9",["DRUID"]="|cFFFF7D0A",
	["MONK"]="|cFF00ff96"
}

-- Defaults
local defaultMCCSaved = {
    ver = modVersion,
    chars = {},
    appearances = {}
}

-- Event handlers
local function OnWardrobeUpdate()
	local appearanceID = C_TransmogCollection.GetLatestAppearance()

	if appearanceID ~= nil then
		mcc:AddAppearance(appearanceID)
        MCCSaved.chars[guid].lastUpdate = time()
	end
end

-- addon setup
function mcc:OnInitialize()
	MCCSaved = MCCSaved or defaultMCCSaved

	if (not MCCSaved.ver or type(MCCSaved.ver) ~= "string") then
		MCCSaved = defaultMCCSaved
	else
		local majV, minV, revV = modVersion:match("(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)")
		local savedMajV, savedMinV, savedRevV = MCCSaved.ver:match("(%d%d?%d?)%.(%d%d?%d?)%.(%d%d?%d?)")

		if savedMajV < majV then
			MCCSaved = defaultMCCSaved
		end
	end

	MCCSaved.ver = modVersion
end

function mcc:OnEnable()
	mcc:RegisterEvent("TRANSMOG_COLLECTION_UPDATED", OnWardrobeUpdate)

	mcc:Init()
	addonLoaded = true
	self:ScheduleTimer("LoadCharInfo", 3)
end

-------------------------------------------------------------------------------

function mcc:Init()
    guid = UnitGUID("player")

    -- Set up character data table
    MCCSaved.chars[guid] = MCCSaved.chars[guid] or {}
    MCCSaved.chars[guid].scanTime = MCCSaved.chars[guid].scanTime or 0
    MCCSaved.chars[guid].lastUpdate = MCCSaved.chars[guid].lastUpdate or 0
end

function mcc:LoadCharInfo()
	if (not addonLoaded or charInfoLoaded) then return end
	guid = UnitGUID("player")

	MCCSaved.chars[guid].charInfo = MCCSaved.chars[guid].charInfo or {}

	local _, realm, _, _, _, _, region = realmInfo:GetRealmInfoByUnit("player")

	if (realm == nil) then
		realm = GetRealmName()
	end

	local regionName = region or GetCurrentRegion()
	local class, classFileName = UnitClass("player")
	local race, raceFileName = UnitRace("player")
	local guildName = GetGuildInfo("player")

	MCCSaved.chars[guid].charInfo.name = UnitName("player")
	MCCSaved.chars[guid].charInfo.faction = UnitFactionGroup("player")
	MCCSaved.chars[guid].charInfo.class = classFileName
	MCCSaved.chars[guid].charInfo.race = raceFileName
	MCCSaved.chars[guid].charInfo.level = UnitLevel("player")

	classColor = colors[classFileName]

	if (realm) then
		MCCSaved.chars[guid].charInfo.realm = realm
	end

	if (regionName) then
		MCCSaved.chars[guid].charInfo.region = regionName
	end

	charInfoLoaded = true

	DEFAULT_CHAT_FRAME:AddMessage("|cFF0070DEMogCollector.com |cFF69CCF0ItemCollector |cFFFFFFFFv" .. modVersion .. " by |cFFFF7D0Atritus|cFFFFFFFF@Mal'Ganis loaded")

	mcc:ScanWardrobe(false)
end

function mcc:HasAppearance(appearanceID)
	return MCCSaved.appearances["app" .. appearanceID] ~= nil
end

function mcc:GetAppearanceItems(appearanceID)
	local items = {}
	local sources = C_TransmogCollection.GetAppearanceSources(appearanceID)

	for j, source in pairs(sources) do
		if source.isCollected then
			local itemLink = string.match(select(6, C_TransmogCollection.GetAppearanceSourceInfo(source.sourceID)), "item[%-?%d:]+")

			if itemLink then
				tinsert(items, mcc:GetItemKey(itemLink))
			end
		end
	end

	return items
end

function mcc:GetItemKey(itemLink)
	if itemLink == nil then return end

	local itemInfo = string.split(itemLink, ":")
	local bonusCount = tonumber(itemInfo[14])
	local key = itemInfo[2]
	
	if bonusCount ~= nil then
		key = key .. "|" .. table.concat(itemInfo, ":", 15, 15 + bonusCount - 1)
	end

	return key
end

-- Scan Wardrobe
function mcc:ScanWardrobe(quiet)
	quiet = quiet or false

	if not C_TransmogCollection or scanningData then
		return false
	end

	if not quiet then
		DEFAULT_CHAT_FRAME:AddMessage("|cFF69CCF0ItemCollector |cFFFFFFFFscanning for new appearances.")
	end

	if wardrobeUpdateHelper == nil or coroutine.status(wardrobeUpdateHelper) == "dead" then
		wardrobeUpdateHelper = mcc:GetWardrobeUpdateHelper(quiet)
	end

	local frame = CreateFrame("Frame")

	frame:SetScript("OnUpdate" , function(self, elapsed)
		if coroutine.status(wardrobeUpdateHelper) ~= "dead" then
			local success, msg = coroutine.resume(wardrobeUpdateHelper)

			if not success then
				print("Error while scanning wardrobe: ", msg)
			end
		end
	end)

	MCCSaved.chars[guid].scanTime = time()
    MCCSaved.chars[guid].lastUpdate = time()
	return
end

function mcc:GetWardrobeUpdateHelper(quiet)
	return coroutine.create(function()
		local newAppearances = 0
		local count = 0

		scanningData = true

		-- save user prefs
		local collected = C_TransmogCollection.GetCollectedShown()
		local uncollected = C_TransmogCollection.GetUncollectedShown()
		local sources = {}
		for i = 1, C_TransmogCollection.GetNumTransmogSources() do
		    sources[i] = not C_TransmogCollection.IsSourceTypeFilterChecked(i)
		end

		-- show all appearances
		C_TransmogCollection.SetCollectedShown(true)
		C_TransmogCollection.SetUncollectedShown(false)
		C_TransmogCollection.SetAllSourceTypeFilters(true)
		C_TransmogCollection.ClearSearch()

		for category = 6, 6 do
			local catApp = C_TransmogCollection.GetCategoryAppearances(category)

			for k, appearance in pairs(catApp) do
				if appearance.isCollected and not appearance.isHideVisual then
					if not mcc:HasAppearance(appearance.visualID) then
						newAppearances = newAppearances + 1
					end

					mcc:AddAppearance(appearance.visualID)
				end
				
				count = count + 1
				if count % 10 == 0 then
					coroutine.yield()
				end
			end
		end

		-- reset user prefs
		C_TransmogCollection.SetCollectedShown(collected)
		C_TransmogCollection.SetUncollectedShown(uncollected)
		for k, v in pairs(sources) do
		    C_TransmogCollection.SetSourceTypeFilter(k, v)
		end

		scanningData = false

		if not quiet then
			DEFAULT_CHAT_FRAME:AddMessage("|cFF69CCF0ItemCollector |cFFFFFFFFscan complete: |cFF69CCF0" .. newAppearances .. " |cFFFFFFFFnew appearances added.")
		end
	end)
end

function mcc:AddAppearance(appearanceID)
	local items = mcc:GetAppearanceItems(appearanceID)
	local appKey = "app" .. appearanceID
	MCCSaved.appearances[appKey] = MCCSaved.appearances[appKey] or {}

	for j, itemStr in pairs(items) do
		if MCCSaved.appearances[appKey][itemStr] == nil then
			MCCSaved.appearances[appKey][itemStr] = 1
		end
	end
end

-- helpers

function string:split(delimiter)
	local result = {}
	local from  = 1
	local delim_from, delim_to = string.find(self, delimiter, from)
	while delim_from do
		table.insert(result, string.sub(self, from , delim_from-1))
		from  = delim_to + 1
		delim_from, delim_to = string.find(self, delimiter, from)
	end
		table.insert(result, string.sub(self, from))
	return result
end

-- slash command
SLASH_ITEMCOLLECTOR1 = '/mcc';
local function handler(msg, editBox)
	if msg == "clear" then
		MCCSaved.appearances = {}
	else
		mcc:ScanWardrobe(false)
	end
end
SlashCmdList["ITEMCOLLECTOR"] = handler;
